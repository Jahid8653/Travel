import React from 'react'
import './Services.css'

export default function Services() {
  return (
    <>
    <div className='styleme4'>
    <h1>This is Services page</h1>
    </div>
    </>
  )
}
