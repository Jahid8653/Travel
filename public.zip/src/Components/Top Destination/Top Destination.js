import React from 'react'
import './Top Destination.css'

export default function TopDestination() {
  return (
    <>
    <div className='styleme6'>
      <h1>This is the Top Destination</h1>
      </div>
    </>
  )
}
