import React from 'react'
import './About.css'

export default function About() {
  return (
    <>
    <div className='styleme5'>
    <h1>This is About page</h1>
    </div>
    </>
  )
}
