import React from 'react'
import './Home.css'
import Carousel from 'react-bootstrap/Carousel';
import Card from 'react-bootstrap/Card';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import { Button } from 'react-bootstrap';


export default function Home() {
  return (
    <>
    
      <Carousel>
        <Carousel.Item className='txt'>
          <img
            className="d-block w-100"
            src="../../Image/Sikkim.jpg"
            alt="First slide"
          />
          <Carousel.Caption>
            <h3 className='text'>Sikkim Tour</h3>
            <p className='text'>We offer best deal in tourism market. Sikkim is one of the top place to visit in eastern India.</p>
          </Carousel.Caption>
        </Carousel.Item>

        <Carousel.Item className='txt'>
          <img
            className="d-block w-100"
            src="../../Image/Manali.jpg"
            alt="Second slide"
          />

          <Carousel.Caption>
            <h3 className='text'>Manali Tour</h3>
            <p className='text'>Manali is a place of many visitors to visit once in lifetime.</p>
          </Carousel.Caption>
        </Carousel.Item>

        <Carousel.Item className='txt'>
          <img
            className="d-block w-100"
            src="../../Image/Goa.jpg"
            alt="Third slide"
          />

          <Carousel.Caption>
            <h3 className='text'>Goa Tour</h3>
            <p className='text'>Goa is a international level sea beach where many foreigners use to visit once in lifetime.</p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel> <br /> <br /> <br />

      <h4>We have the best destination package in the market. We have domestic and international tour package
          with budget fiendly. Our dedicated team will help you to reach your dream destination with the help
          of every possible way. </h4> <br /> <br />

      <h2 className='best'> Trending Indian Destinations</h2> <br />
      <Row xs={1} md={4} className="g-5">
        <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/Sikkim.jpg" />
            <Card.Body>
              <Card.Title>Sikkim</Card.Title>
              <Card.Text>
                Sikkim is the best place to visit in eastern India. It's a dream for many people to visit Sikkim once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.6999/- </h5>
                <h6 className='pot'>3D & 2N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/Manali.jpg" />
            <Card.Body>
              <Card.Title>Manali</Card.Title>
              <Card.Text>
                Manali is the best place to visit in eastern India. It's a dream for many people to visit Manali once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.9999/- </h5>
                <h6 className='pot'>4D & 3N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col className='top'>
          <Card>
            <Card.Img variant="top" alt="Goa" src="../../Image/Goa.jpg" />
            <Card.Body>
              <Card.Title>Goa Beach</Card.Title>
              <Card.Text>
                Goa is the best place to visit in western India. It's a dream for many people to visit Goa once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.8999/-</h5>
                <h6 className='pot'>3D & 2N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/J&K.jpg" />
            <Card.Body>
              <Card.Title>Jammu and Kashmir</Card.Title>
              <Card.Text>
                Jammu and Kashmir is the best place to visit in nortern India. It's a dream for many people to visit Jammu and Kashmir once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.14999/- </h5>
                <h6 className='pot'>5D & 4N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/Kerala.jpg" />
            <Card.Body>
              <Card.Title>Kerala</Card.Title>
              <Card.Text>
                Kerala is the best place to visit in southern India. It's a dream for many people to visit Kerala once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.13999/- </h5>
                <h6 className='pot'>5D & 4N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/Ooty.jpg" />
            <Card.Body>
              <Card.Title>Ooty</Card.Title>
              <Card.Text>
                Ooty is the best place to visit in southern India. It's a dream for many people to visit Ooty once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.17999/- </h5>
                <h6 className='pot'>6D & 5N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/Shimla.jpg" />
            <Card.Body>
              <Card.Title>Shimla</Card.Title>
              <Card.Text>
                Shimla is the best place to visit in eastern India. It's a dream for many people to visit Shimla once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.17999/- </h5>
                <h6 className='pot'>6D & 5N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/Sundarban.jpg" />
            <Card.Body>
              <Card.Title>Sundarban</Card.Title>
              <Card.Text>
                Sundarban is the best place to visit in eastern India. It's a dream for many people to visit Sundarban once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.7999/- </h5>
                <h6 className='pot'>3D & 2N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/Taj Mahal.jpg" />
            <Card.Body>
              <Card.Title>Taj Mahal</Card.Title>
              <Card.Text>
                Taj Mahal is the best place to visit in southern India. It's a dream for many people to visit Taj Mahal once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.13999/- </h5>
                <h6 className='pot'>2D & 1N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
      </Row> <br /> <br />
      <h2 className='best'> Trending International Destinations</h2> <br />
      <Row xs={1} md={4} className="g-5">
      <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/Dubai.jpg" />
            <Card.Body>
              <Card.Title>Dubai</Card.Title>
              <Card.Text>
              Dubai is the best place to visit in gulf. It's a dream for many people to visit Dubai once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.49999/- </h5>
                <h6 className='pot'>4D & 3N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/Malaysia.jpg" />
            <Card.Body>
              <Card.Title>Malaysia</Card.Title>
              <Card.Text>
              Malaysia is the best place to visit. It's a dream for many people to visit Malaysia once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.59999/- </h5>
                <h6 className='pot'>5D & 4N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/Maldive.jpg" />
            <Card.Body>
              <Card.Title>Maldive</Card.Title>
              <Card.Text>
              Maldive is the best place to visit. It's a dream for many people to visit Maldive once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.54999/- </h5>
                <h6 className='pot'>4D & 3N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/Singapore.jpg" />
            <Card.Body>
              <Card.Title>Singapore</Card.Title>
              <Card.Text>
              Singapore is the best place to visit. It's a dream for many people to visit Singapore once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.89999/- </h5>
                <h6 className='pot'>4D & 3N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/Bali.jpg" />
            <Card.Body>
              <Card.Title>Bali</Card.Title>
              <Card.Text>
              Bali is the best place to visit. It's a dream for many people to visit Bali once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.39999/- </h5>
                <h6 className='pot'>4D & 3N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col className='top'>
          <Card>
            <Card.Img variant="top" src="../../Image/Bangkok.jpg" />
            <Card.Body>
              <Card.Title>Bangkok</Card.Title>
              <Card.Text>
              Bangkok is the best place to visit. It's a dream for many people to visit Bangkok once in lifetime. <br /> <br />
                <h5 className='pot2'>Starting from Rs.79999/- </h5>
                <h6 className='pot'>4D & 3N</h6>
                <Button variant="primary">Booking Open</Button>
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        </Row>
    </>

  )
}
