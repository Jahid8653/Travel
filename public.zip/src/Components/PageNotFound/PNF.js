import React from 'react'
import './PNF.css'

export default function PNF() {
  return (
    <>
    <div className='styleme2'>
    <h1>Sorry!!! Page not found!</h1>
    </div>
    </>
  )
}
