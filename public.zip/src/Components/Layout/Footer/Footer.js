import React from 'react'
import './Footer.css'

export default function Footer() {
  return (
    <div className= "Footer">
    <h6> Copyright @ 2022 </h6>
    </div>
  )
}
