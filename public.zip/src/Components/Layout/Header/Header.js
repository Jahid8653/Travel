import React from 'react'
import { Nav, Navbar } from 'react-bootstrap'
import { Container } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import './Header.css'

export default function Header() {
  return (
    <div className='Header'>
   <Navbar bg="dark" variant="dark">
        <Container>
          <Navbar.Brand as={Link} to="/">Jahmo</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link as={Link} to="/home">Home</Nav.Link>
            <Nav.Link as={Link} to="/about">About</Nav.Link>
            <Nav.Link as={Link} to="/packages">Packages</Nav.Link>
            <Nav.Link as={Link} to="/services">Services</Nav.Link>
            <Nav.Link as={Link} to="/topdestination">Top Destination</Nav.Link>
            <Nav.Link as={Link} to="/blog">Blog</Nav.Link>
          </Nav>
        </Container>
      </Navbar>
      <br />  

    </div>
  )
}
