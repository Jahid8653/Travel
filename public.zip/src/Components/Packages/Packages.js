import React from 'react'
import './Packages.css'

export default function Packages() {
  return (
    <>
    <div className='styleme7'>
    <h1>This is our favourite packages</h1>
    </div>
    </>
  )
}
