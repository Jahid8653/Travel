import './App.css';
import RootRouting from './Routing/RootRouting';


function App() {
  return (
    <div>
      <RootRouting/>
    </div>
  );
}

export default App;
