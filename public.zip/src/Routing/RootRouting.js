// import React, { Component } from 'react'
import { Route, Routes, BrowserRouter as Router} from 'react-router-dom'
import Home from '../Components/Home/Home'
import About from '../Components/About/About'
import Packages from '../Components/Packages/Packages'
import Services from '../Components/Services/Services'
import TopDestination from '../Components/Top Destination/Top Destination'
import Header from '../Components/Layout/Header/Header'
import Footer from '../Components/Layout/Footer/Footer'
import PNF from '../Components/PageNotFound/PNF'




export default function RootRouting() {
    return (
        <Router>
        <Header/>
         <Routes>
          <Route path="" element={<Home/>}/>
          <Route path="home" element={<Home/>}/>
          <Route path="about" element={<About/>}/>
          <Route path="packages" element={<Packages/>}/>
          <Route path="services" element={<Services/>}/>
          <Route path="topdestination" element={<TopDestination/>}/>
          <Route path="*" element={<PNF/>}/>
         
         </Routes>
         <Footer/>
        </Router>
    )
  }